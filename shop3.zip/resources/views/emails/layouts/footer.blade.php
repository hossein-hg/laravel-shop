
<!-- start footer -->
<footer class="footer">
    <section class="container-xxl my-4">
        <section class="row my-5">
            <section class="col">
                <section class="fw-bold">شرکت آمازون</section>
                <section class="text-muted footer-intro">ما همواره تلاش می کنیم بهترین خدمات را به مشتریان آمازون ارائه کنیم. به شما کمک می کنیم بهترین انتخاب را داشته باشید و با اطمینان خاطر خرید را انجام بدهید و در کوتاه ترین زمان ممکن کالای خود را دریافت کنید. همچنین ما 24 ساعته در هفت روز هفته به مشتریان مان خدمات ارائه می دهیم. و 7 روز ضمانت برگشت برای تمامی کالاها داریم.</section>
            </section>
        </section>

        <section class="row border-top pt-4">
            <section class="col">
                <section class="text-muted footer-intro text-center">کلیه حقوق این وبسایت متعلق به شرکت آمازون می باشد.</section>
            </section>
        </section>
    </section>
</footer>
<!-- end footer -->

