<?php if(session('swal-confirm-delete')): ?>
    <script>
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                )
            }
        })
    </script>
<?php endif; ?>
<?php /**PATH E:\laravel\shop\resources\views/admin/alerts/sweetalert/delete-confirm.blade.php ENDPATH**/ ?>