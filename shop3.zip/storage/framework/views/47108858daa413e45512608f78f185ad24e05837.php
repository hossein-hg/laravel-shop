<?php $__env->startSection('head-tag'); ?>
    <title>علاقه مندی ها</title>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <section class="">
        <section id="main-body-two-col" class="container-xxl body-container">
            <section class="row">
                <aside id="sidebar" class="sidebar col-md-3">


                    <section class="content-wrapper bg-white p-3 rounded-2 mb-3">
                        <?php echo $__env->make('customer.layouts.partials.profile-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </section>

                </aside>
                <main id="main-body" class="main-body col-md-9">
                    <section class="content-wrapper bg-white p-3 rounded-2 mb-2">

                        <!-- start vontent header -->
                        <section class="content-header mb-4">
                            <section class="d-flex justify-content-between align-items-center">
                                <h2 class="content-header-title">
                                    <span>لیست علاقه های من</span>
                                </h2>
                                <section class="content-header-link">
                                    <!--<a href="#">مشاهده همه</a>-->
                                </section>
                            </section>
                        </section>
                        <!-- end vontent header -->

                        <?php $__empty_1 = true; $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <section id="section<?php echo e($favorite->id); ?>" class="cart-item d-flex py-3">
                            <section class="cart-img align-self-start flex-shrink-1"><img src="<?php echo e(asset($favorite->image['indexArray']['medium'])); ?>" alt=""></section>
                            <section class="align-self-start w-100">
                                <p class="fw-bold"> <?php echo e($favorite->name); ?></p>
                                <?php if($favorite->colors != null): ?>
                                    <?php $__currentLoopData = $favorite->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><span style="background-color: <?php echo e($color->color); ?>;" class="cart-product-selected-color me-1"></span> <span>  <?php echo e($color->color_name); ?></span></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>


                                <?php if($favorite->guarantees != null): ?>
                                    <?php $__currentLoopData = $favorite->guarantees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guarantee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><span  class=""></span> <span>  <?php echo e($guarantee->name); ?></span></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <p><i class="fa fa-store-alt cart-product-selected-store me-1"></i> <span>کالا موجود در انبار</span></p>
                                <section>
                                    <a style="cursor: pointer"  data-url="<?php echo e(route('customer.market.add-to-favorite',[$favorite->slug])); ?>" id="favorite<?php echo e($favorite->id); ?>" data-bs-toggle="tooltip" data-bs-placement="left"  onclick="addToFavorite(<?php echo e($favorite->id); ?>)">
                                        <i class="fa fa-heart"></i>
                                        <?php echo e($favorite->users == null ? 'افزودن به علاقه مندی ها' : 'حذف از علاقه مندی ها'); ?></a>
                                </section>
                            </section>
                            <section class="align-self-end flex-shrink-1">
                                <section class="text-nowrap fw-bold"><?php echo e(\App\Helpers\priceFormat($favorite->price)); ?> تومان</section>
                            </section>
                        </section>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <section class="order-item">
                                <section class="d-flex justify-content-between">
                                    <p>
                                        محصولی یافت نشد
                                    </p>
                                </section>
                            </section>
                        <?php endif; ?>


                    </section>
                </main>
            </section>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function addToFavorite(id){
            let favorite = $('#favorite'+id)
            let section = $('#section'+id)
            let icon = $('#fa'+id)
            let url = favorite.attr('data-url')
            $.ajax({
                url,
                type:'GET',
                success:(res)=>{
                    let {status} = res;

                    if (status === 1){

                        icon.addClass('text-danger')
                        icon.removeClass('text-dark')
                        favorite.attr('data-bs-original-title','حذف از علاقه مندی ها')

                    }
                    else if (status === 2) {
                        section.remove()
                        icon.addClass('text-dark')
                        icon.removeClass('text-danger')
                        favorite.attr('data-bs-original-title','افزودن به علاقه مندی ها')


                    }

                    else if (status === 3) {

                        $('.toast').toast('show')

                    }
                },
                error:()=>{


                }

            })

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.master-one-col', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\shop\resources\views/customer/profile/my-favorites.blade.php ENDPATH**/ ?>