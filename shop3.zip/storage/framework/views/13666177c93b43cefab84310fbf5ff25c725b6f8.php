<?php $__env->startSection('head-tag'); ?>
    <title>گالری کالا</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item font-size-12"> <a href="#">خانه</a></li>
            <li class="breadcrumb-item font-size-12"> <a href="#">بخش فروش</a></li>
            <li class="breadcrumb-item font-size-12"> <a href="#">کالا</a></li>
            <li class="breadcrumb-item font-size-12 active" aria-current="page"> گالری کالا</li>
        </ol>
    </nav>

    <section >

                <section class="row">
                    <section class="col-12">
                        <section class="main-body-container">
                            <section class="main-body-container-header">
                                <h4>
                                    ایجاد تصویر
                                </h4>

                            </section>

                            <section class="d-flex justify-content-between align-items-center mt-4 mb-3 pt-2 border-bottom">




                            </section>

                            <section >
                                <form enctype="multipart/form-data" action="<?php echo e(route('admin.market.gallery.store',[$product->id])); ?>" id="form" method="post">
                                    <?php echo csrf_field(); ?>
                                    <section class="row">


                                        <section class="col-12 col-md-6">
                                            <div class="form-group">
                                                <label for="">تصویر </label>
                                                <input name="image" type="file" class="form-control form-control-sm">
                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </section>

                                        <section class="col-12">
                                            <button class="btn btn-primary btn-sm">ثبت</button>
                                        </section>

                                    </section>
                                </form>

                            </section>

                        </section>
                    </section>
                </section>



    </section>

    <section class="row">
        <section class="col-12">
            <section class="main-body-container">
                <section class="main-body-container-header">
                    <h4>
                        گالری کالا
                    </h4>

                </section>





            </section>
            <section class="row">
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <section class="col-md-4 mt-2" id="tr<?php echo e($image->id); ?>">
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src="<?php echo e(asset($image->image['indexArray']['medium'])); ?>" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>

                            <a  id="delete<?php echo e($image->id); ?>" onclick="deleteRecord(<?php echo e($image->id); ?>)" data-url="<?php echo e(route('admin.market.gallery.destroy',[$image->id])); ?>" class="btn btn-danger btn-sm text-white"><i class="fa fa-edit"></i> حذف</a>
                        </div>
                    </div>
                </section>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>


        </section>






    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>



        function deleteRecord(id){
            Swal.fire({
                title: 'آیا مطمین هستید؟',
                text: "می خواهید رکورد را حذف کنید؟",
                icon: 'warning',
                showCancelButton: true,
                cancelButtonText: 'انصراف',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'بله, حذف کن!'
            }).then((result) => {

                if (result.value) {
                    let element = $('#delete'+id)
                    let tr = $('#tr'+id)
                    let url = element.attr('data-url')
                    console.log(result)
                    $.ajax({
                        url,
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type:'POST',
                        data:{
                            '_method': 'delete'
                        },
                        success:(res)=>{
                            console.log(res)
                            tr.remove()
                            Swal.fire({
                                icon: 'success',
                                title: 'موفق',
                                text: 'رکورد با موفقیت حذف شد',
                                confirmButtonText : 'باشه'
                            })

                        }
                    })
                }
            })


        }

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\shop\resources\views/admin/market/product/gallery/index.blade.php ENDPATH**/ ?>