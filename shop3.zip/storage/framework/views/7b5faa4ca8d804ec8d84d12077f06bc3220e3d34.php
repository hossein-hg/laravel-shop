<?php $__env->startSection('head-tag'); ?>
    <title>ویرایش دسترسی ها </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item font-size-12"> <a href="#">خانه</a></li>
            <li class="breadcrumb-item font-size-12"> <a href="#">بخش کاربران</a></li>

            <li class="breadcrumb-item font-size-12 " > <a href="#">نقش ها</a></li>
            <li class="breadcrumb-item font-size-12 active" aria-current="page"> ویرایش دسترسی ها</li>
        </ol>
    </nav>

    <section class="row">
        <section class="col-12">
            <section class="main-body-container">
                <section class="main-body-container-header">
                    <h4>
                        ویرایش دسترسی ها
                    </h4>

                </section>

                <section class="d-flex justify-content-between align-items-center mt-4 mb-3 pt-2 border-bottom">
                    <a href="<?php echo e(route('admin.user.role.index')); ?>" class="btn btn-info btn-sm"> بازگشت </a>



                </section>

                <section >
                    <form action="<?php echo e(route('admin.user.role.permission-update',[$role->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <section class="row">






<?php
    $rolePermissionsArray = $role->permissions->pluck('id')->toArray();
?>

                            <section class="col-12">
                                <section class="row">
                                <section class="col-12 col-md-5">
                                    <div class="form-group">
                                        <label for=""><h6>نام نقش</h6></label> : <span><?php echo e($role->name); ?></span>
                                        <section></section>
                                    </div>
                                </section>

                                <section class="col-12 col-md-5">
                                    <div class="form-group">
                                        <label for=""><h6>توضیح نقش</h6></label> : <span><?php echo e($role->description); ?></span>
                                        <section></section>
                                    </div>
                                </section>
                                </section>
                                <section class="row border-top mt-3 py-3">

                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <section class="col-md-3">
                                        <div class="form-check">
                                            <input name="permissions[]" id="<?php echo e($permission->id); ?>" type="checkbox" class="form-check-input" value="<?php echo e($permission->id); ?>" <?php echo e(in_array($permission->id,$rolePermissionsArray) ? 'checked' : ''); ?> >
                                            <label for="<?php echo e($permission->id); ?>" class="form-check-label mr-4"> <?php echo e($permission->name); ?></label>
                                        </div>
                                        <?php $__errorArgs = ['permissions.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </section>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </section>

                                <section class="col-12 col-md-2 mt-md-4">
                                    <button class="btn btn-primary btn-sm">ثبت</button>
                                </section>


                            </section>

                        </section>
                    </form>

                </section>

            </section>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\shop\resources\views/admin/user/role/permission-role.blade.php ENDPATH**/ ?>