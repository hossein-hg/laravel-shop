<?php $__env->startSection('head-tag'); ?>
    <title>مقایسه محصولات </title>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <section class="">
        <section id="main-body-two-col" class="container-xxl body-container">
            <section class="row">
                <aside id="sidebar" class="sidebar col-md-3">


                    <section class="content-wrapper bg-white p-3 rounded-2 mb-3">
                        <?php echo $__env->make('customer.layouts.partials.profile-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </section>

                </aside>
                <main id="main-body" class="main-body col-md-9">
                    <section class="content-wrapper bg-white p-3 rounded-2 mb-2">

                        <!-- start vontent header -->
                        <section class="content-header mb-4">
                            <section class="d-flex justify-content-between align-items-center">
                                <h2 class="content-header-title">
                                    <span>لیست مقایسه های من</span>
                                </h2>
                                <section class="content-header-link">
                                    <!--<a href="#">مشاهده همه</a>-->
                                </section>
                            </section>
                        </section>
                        <!-- end vontent header -->


<?php if($products->count() > 0): ?>
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>نام محصول</td>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="product<?php echo e($product->id); ?>"><?php echo e($product->name); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>

                                <tr>
                                    <td>قیمت محصول</td>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="product<?php echo e($product->id); ?>" ><?php echo e(\App\Helpers\priceFormat($product->price)); ?> تومان   </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>

                                <tr>
                                    <td>عکس محصول</td>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="product<?php echo e($product->id); ?>"><img src="<?php echo e(asset($product->image['indexArray']['small'])); ?>" alt=""></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>

                                <tr>
                                    <td></td>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="product<?php echo e($product->id); ?>">
                                            <?php if($product->compares->contains(auth()->user()->compare->id)): ?>
                                                <a style="cursor: pointer"  data-url="<?php echo e(route('customer.market.add-to-compare',[$product->slug])); ?>" id="compare<?php echo e($product->id); ?>" data-bs-toggle="tooltip" data-bs-placement="left" title="حذف از مقایسه" onclick="addToCompare(<?php echo e($product->id); ?>)">
                                                    <i id="co1<?php echo e($product->id); ?>" class="fa fa-industry text-danger mx-1"></i><span id="span-delete1">حذف از مقایسه</span>
                                                </a>
                                            <?php else: ?>
                                                <a style="cursor: pointer"  data-url="<?php echo e(route('customer.market.add-to-compare',[$product->slug])); ?>" id="compare<?php echo e($product->id); ?>" data-bs-toggle="tooltip" data-bs-placement="left" title="افزودن به مقایسه" onclick="addToCompare(<?php echo e($product->id); ?>)">
                                                    <i id="co1<?php echo e($product->id); ?>" class="fa fa-industry text-dark mx-1"></i><span id="span-add1">افزودن به مقایسه</span>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <h3>محصولی برای مقایسه یافت نشد!</h3>
<?php endif; ?>

                    </section>
                </main>
            </section>
        </section>
    </section>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script>

        function addToCompare(id){
            let tr = $('.product'+id)

            let compare = $('#compare'+id)
            let url = compare.attr('data-url')
            $.ajax({
                url,
                type:'GET',
                success:(res)=>{
                    let {status} = res;
                    console.log(status)

                     if (status === 2) {

                         tr.remove()

                    }

                    else if (status === 3) {

                        $('.toast').toast('show')

                    }
                },
                error:()=>{
                    errorToast('ارتباط برقرار نشد!')

                }

            })

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.master-one-col', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\shop\resources\views/customer/profile/my-compares.blade.php ENDPATH**/ ?>