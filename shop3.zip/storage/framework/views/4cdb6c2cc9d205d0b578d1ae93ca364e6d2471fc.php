<?php $__env->startSection('content'); ?>

<h2><?php echo e($details['subject']); ?></h2>
<p><?php echo $details['body']; ?>  </p>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\shop\resources\views/emails/send-admin-email.blade.php ENDPATH**/ ?>