<?php $__env->startSection('head-tag'); ?>
    <title>پرداخت ها</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item font-size-12"> <a href="#">خانه</a></li>
            <li class="breadcrumb-item font-size-12"> <a href="#">بخش فروش</a></li>
            <li class="breadcrumb-item font-size-12 active" aria-current="page"> پرداخت ها</li>
        </ol>
    </nav>

    <section class="row">
        <section class="col-12">
            <section class="main-body-container">
                <section class="main-body-container-header">
                    <h4>
                        پرداخت ها
                    </h4>

                </section>

                <section class="d-flex justify-content-between align-items-center mt-4 mb-3 pt-2 border-bottom">
                    <a href="<?php echo e(route('admin.market.category.create')); ?>" class="btn btn-info btn-sm disabled">ایجاد پرداخت </a>

                    <div class="max-width-16-rem">
                        <input type="text" placeholder="جست و جو" class="form-control form-control-sm form-text">
                    </div>

                </section>

                <section class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>مقدار</th>
                            <th>کد تراکنش</th>
                            <th>بانک </th>
                            <th>پرداخت کننده </th>
                            <th>وضعیت پرداخت</th>
                            <th>نوع پرداخت</th>
                            <th class="max-width-16-rem text-center"><i class="fa fa-cog"></i> تنظیمات</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e(++$key); ?></th>
                            <th><?php echo e($payment->amount); ?></th>
                            <td>نمایشگر</td>
                            <td><?php echo e($payment->paymentable->gate_way ?? '-'); ?></td>
                            <td><?php echo e($payment->user->fullName); ?></td>
                            <td><?php echo e($payment->paymentStatus()); ?></td>
                            <td><?php echo e($payment->typePayment()); ?></td>
                            <td class="width-22-rem text-left">
                                <a href="<?php echo e(route('admin.market.payment.show',[$payment->id])); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> مشاهده</a>
                                <a href="<?php echo e(route('admin.market.payment.canceled',[$payment->id])); ?>"  class="btn btn-warning btn-sm"><i class="fa fa-clock"></i> باطل کردن</a>
                                <a href="<?php echo e(route('admin.market.payment.returned',[$payment->id])); ?>"  class="btn btn-danger btn-sm"><i class="fa fa-reply"></i> برگرداندن</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </section>

            </section>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\shop\resources\views/admin/market/payment/index.blade.php ENDPATH**/ ?>