<?php $__env->startSection('head-tag'); ?>
    <title>نمایش  نظر</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item font-size-12"> <a href="#">خانه</a></li>
            <li class="breadcrumb-item font-size-12"> <a href="#">بخش محتوی</a></li>
            <li class="breadcrumb-item font-size-12 " > <a href="#">نظرات</a></li>
            <li class="breadcrumb-item font-size-12 active" aria-current="page"> نمایش نظر</li>
        </ol>
    </nav>

    <section class="row">
        <section class="col-12">
            <section class="main-body-container">
                <section class="main-body-container-header">
                    <h4>
                        نمایش نظر
                    </h4>

                </section>

                <section class="d-flex justify-content-between align-items-center mt-4 mb-3 pt-2 border-bottom">
                    <a href="<?php echo e(route('admin.content.comment.index')); ?>" class="btn btn-info btn-sm"> بازگشت </a>
                </section>

                <section class="card mb-3">
                    <section class="card-header text-white bg-custom-yellow">
                           <?php echo e($comment->user->fullName); ?>  - <?php echo e($comment->user->id); ?>

                    </section>
                    <section class="card-body">
                        <h5 class="card-title"> پست : <?php echo e($comment->commentable->title); ?></h5>
                        <p class="card-text"><?php echo e($comment->body); ?></p>
                    </section>
                </section>
                <?php if($comment->parent_id == null): ?>
                <section >
                    <form method="post" action="<?php echo e(route('admin.content.comment.answer',[$comment->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <section class="row">

                            <section class="col-12 ">
                                <div class="form-group">
                                    <label for="">پاسخ ادمین </label>
                                    <textarea name="body" rows="4" class="form-control form-control-sm"></textarea>
                                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </section>
                            <section class="col-12">
                                <button class="btn btn-primary btn-sm">ثبت</button>
                            </section>

                        </section>
                    </form>

                </section>
                <?php endif; ?>

            </section>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\shop\resources\views/admin/content/comment/show.blade.php ENDPATH**/ ?>