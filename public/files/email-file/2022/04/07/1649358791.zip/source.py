import csv
# For the average
from statistics import mean


def calculate_averages(input_file_name, output_file_name):
    b = []
    with open(input_file_name) as f:
        reader = csv.reader(f)
        for row in reader:
            b = b + [row]
    for i in range(0, len(b)):
        for j in range(1, len(b[i])):
            b[i][j] = int(b[i][j])

    m = []
    for k in range(0, len(b)):
        m = m + [mean(b[k][1:])]

    o = open(output_file_name, 'w')
    for p in range(0, len(b)):
        o.write('%s,%s' % (b[p][0], str(m[p])))
        o.write('\n')

def calculate_sorted_averages(input_file_name, output_file_name):
    b = []
    with open(input_file_name) as f:
        reader = csv.reader(f)
        for row in reader:
            b = b + [row]
    for i in range(0, len(b)):
        for j in range(1, len(b[i])):
            b[i][j] = int(b[i][j])
    m = []
    for k in range(0, len(b)):
        m = m + [mean(b[k][1:])]

    h = dict()
    for t in range(0, len(m)):
        h[m[t]] = [b[t][0]]
    h = list(h.items())
    h.sort()
    o = open(output_file_name, 'w')
    for p in range(0, len(h)):
        o.write('%s,%s' % (h[p][1][0], str(h[p][0])))
        o.write('\n')

def calculate_three_best(input_file_name, output_file_name):
    b = []
    with open(input_file_name) as f:
        reader = csv.reader(f)
        for row in reader:
            b = b + [row]
    for i in range(0, len(b)):
        for j in range(1, len(b[i])):
            b[i][j] = int(b[i][j])
    m = []
    for k in range(0, len(b)):
        m = m + [mean(b[k][1:])]
    h = dict()
    for t in range(0, len(m)):
        h[m[t]] = [b[t][0]]
    h = list(h.items())
    h.sort()
    h.reverse()
    o = open(output_file_name, 'w')
    for p in range(0, 3):
        o.write('%s,%s' % (h[p][1][0], str(h[p][0])))
        o.write('\n')

def calculate_three_worst(input_file_name, output_file_name):
    b = []
    with open(input_file_name) as f:
        reader = csv.reader(f)
        for row in reader:
            b = b + [row]
    for i in range(0, len(b)):
        for j in range(1, len(b[i])):
            b[i][j] = int(b[i][j])
    m = []
    for k in range(0, len(b)):
        m = m + [mean(b[k][1:])]
    h = dict()
    for t in range(0, len(m)):
        h[m[t]] = [b[t][0]]
    h = list(h.items())
    h.sort()
    o = open(output_file_name, 'w')
    for p in range(0, 3):
        o.write('%s' % (str(h[p][0])))
        o.write('\n')

def calculate_average_of_averages(input_file_name, output_file_name):
    b = []
    a=input()
    with open(input_file_name) as f:
        reader = csv.reader(f)
        for row in reader:
            b = b + [row]
    for i in range(0, len(b)):
        for j in range(1, len(b[i])):
            b[i][j] = int(b[i][j])
    m = []
    for k in range(0, len(b)):
        m = m + [mean(b[k][1:])]
    h = dict()
    for t in range(0, len(m)):
        h[m[t]] = [b[t][0]]
    h = list(h.items())
    h.sort()
    s = []
    for i in range(0, len(h)):
        s = s + [h[i][0]]
    s = mean(s)
    o = open(output_file_name, 'w')
    o.write('%s' % (str(s)))
