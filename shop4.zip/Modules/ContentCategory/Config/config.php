<?php

return [
    'name' => 'ContentCategory'
];
