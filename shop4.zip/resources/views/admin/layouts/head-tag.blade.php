<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href={{asset("admin-assets/css/bootstrap/bootstrap.min.css")}}>
<link rel="stylesheet" href={{asset("admin-assets/fontawesome/css/all.min.css")}}>
<link rel="stylesheet" href={{asset("admin-assets/css/animate.min.css")}}>
<link rel="stylesheet" href={{asset("admin-assets/css/grid.css")}}>
<link rel="stylesheet" href={{asset("admin-assets/css/style.css")}}>
<link rel="stylesheet" href={{asset("admin-assets/select2/css/select2.min.css")}}>
<link rel="stylesheet" href={{asset("admin-assets/sweetalert/sweetalert2.css")}}>


