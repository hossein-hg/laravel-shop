<!-- start header -->
<header class="header mb-4">


    <!-- start top-header logo, searchbox and cart -->
    <section class="top-header">
        <section class="container-xxl ">
            <section class="d-flex justify-content-between align-items-center py-3">
                <section class=""><a class="text-decoration-none" href="<?php echo e(route('customer.home')); ?>"><img src="<?php echo e(asset('customer-assets/images/logo/8.png')); ?>" alt="logo"></a></section>

            </section>
        </section>
    </section>
    <!-- end top-header logo, searchbox and cart -->


</header>
<!-- end header --><?php /**PATH E:\laravel\shop\resources\views/emails/layouts/header.blade.php ENDPATH**/ ?>