<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href=<?php echo e(asset("admin-assets/css/bootstrap/bootstrap.min.css")); ?>>
<link rel="stylesheet" href=<?php echo e(asset("admin-assets/fontawesome/css/all.min.css")); ?>>
<link rel="stylesheet" href=<?php echo e(asset("admin-assets/css/animate.min.css")); ?>>
<link rel="stylesheet" href=<?php echo e(asset("admin-assets/css/grid.css")); ?>>
<link rel="stylesheet" href=<?php echo e(asset("admin-assets/css/style.css")); ?>>
<link rel="stylesheet" href=<?php echo e(asset("admin-assets/select2/css/select2.min.css")); ?>>
<link rel="stylesheet" href=<?php echo e(asset("admin-assets/sweetalert/sweetalert2.css")); ?>>


<?php /**PATH E:\laravel\shop\resources\views/admin/layouts/head-tag.blade.php ENDPATH**/ ?>