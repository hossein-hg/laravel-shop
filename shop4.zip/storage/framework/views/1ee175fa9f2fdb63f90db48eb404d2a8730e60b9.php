
<section class="sidebar-nav-item">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <span class="sidebar-nav-item-title">
        <a href="<?php echo e(route('customer.products',[$category->id,'search'=>request()->search,'sort'=>5,'min_price'=>request()->min_price,'max_price'=>request()->max_price,'brands'=>request()->brands])); ?>" class="d-inline"><?php echo e($category->name); ?></a>
        <?php if($category->categories->count() > 0): ?>
            <i class="fa fa-angle-left"></i>
        <?php endif; ?>
    </span>
        <?php echo $__env->make('customer.layouts.partials.sub-categories',['categories'=>$category->categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</section>
<?php /**PATH E:\laravel\shop\resources\views/customer/layouts/partials/categories.blade.php ENDPATH**/ ?>