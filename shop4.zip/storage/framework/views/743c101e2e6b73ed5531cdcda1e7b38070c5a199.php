<?php if(session('swal-error')): ?>
    <script>
        $(document).ready(function (){
            Swal.fire({
                icon: 'error',
                title: 'خطا',
                text: '<?php echo e(session('swal-error')); ?>',
                confirmButtonText : 'باشه'
            })
        })
    </script>
<?php endif; ?>
<?php /**PATH E:\laravel\shop\resources\views/admin/alerts/sweetalert/error.blade.php ENDPATH**/ ?>