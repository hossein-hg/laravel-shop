<?php $__env->startSection('head-tag'); ?>
    <title>سبد خرید</title>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <!-- start main one col -->
    <main id="main-body-one-col" class="main-body">

        <!-- start cart -->
        <section class="mb-4">
            <section class="container-xxl" >
                <section class="row">
                    <section class="col">
                        <!-- start vontent header -->
                        <section class="content-header">
                            <section class="d-flex justify-content-between align-items-center">
                                <h2 class="content-header-title">
                                    <span>سبد خرید شما</span>
                                </h2>
                                <section class="content-header-link">
                                    <!--<a href="#">مشاهده همه</a>-->
                                </section>
                            </section>
                        </section>
                        <form action="<?php echo e(route('customer.sales-process.update-cart')); ?>" id="" method="post">
                        <section class="row mt-4">
                            <section class="col-9">
                                <section class="content-wrapper bg-white p-3 rounded-2">

                                        <?php echo csrf_field(); ?>
                                        <?php
                                            $totalProductPrice = 0;
                                            $totalDiscount = 0;
                                        ?>
                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $totalProductPrice += $item->cartItemProductPrice();
                                                $totalDiscount += $item->cartItemProductDiscount();
                                            ?>
                                    <section id="section<?php echo e($item->id); ?>" class="cart-item d-flex py-3">
                                        <section class="cart-img align-self-start flex-shrink-1"><img src="<?php echo e($item->product->image['indexArray']['medium']); ?>" alt=""></section>
                                        <section class="align-self-start w-100">
                                            <p class="fw-bold"><?php echo e($item->product->name); ?>    </p>
                                            <?php if(!empty($item->color)): ?>
                                            <p>
                                                <span style="background-color: <?php echo e($item->color->color); ?>;" class="cart-product-selected-color me-1"></span> <span><?php echo e($item->color->color_name); ?></span>
                                            </p>
                                            <?php else: ?>
                                                <p>رنگ منتخب وجود ندارد</p>
                                            <?php endif; ?>
                                            <?php if(!empty($item->guarantee)): ?>
                                            <p>
                                                <i class="fa fa-shield-alt cart-product-selected-warranty me-1"></i> <span> <?php echo e($item->guarantee->name); ?></span>
                                            </p>
                                            <?php else: ?>
                                                <p>گارانتی منتخب وجود ندارد</p>
                                            <?php endif; ?>
                                            <p><i class="fa fa-store-alt cart-product-selected-store me-1"></i> <span>کالا موجود در انبار</span></p>
                                            <section>
                                                <section class="cart-product-number d-inline-block ">
                                                    <button class="cart-number cart-number-down" type="button">-</button>
                                                    <input class="number" data-product-price="<?php echo e($item->cartItemProductPrice()); ?>" data-product-discount="<?php echo e($item->cartItemProductDiscount()); ?>"  type="number" min="1" max="5" step="1" value="<?php echo e($item->number); ?>" name="number[<?php echo e($item->id); ?>]" readonly="readonly">
                                                    <button class="cart-number cart-number-up" type="button">+</button>
                                                </section>
                                                <a style="cursor: pointer" data-url="<?php echo e(route('customer.sales-process.remove-from-cart',[$item->id])); ?>" id="delete<?php echo e($item->id); ?>" class="text-decoration-none ms-4 cart-delete"  onclick="deleteRecord(<?php echo e($item->id); ?>)"><i class="fa fa-trash-alt"></i> حذف از سبد</a>
                                            </section>
                                        </section>
                                        <section class="align-self-end flex-shrink-1">
                                            <?php if(!empty($item->product->activeAmazingSales())): ?>
                                            <section class="cart-item-discount text-danger text-nowrap mb-1">تخفیف <?php echo e(\App\Helpers\priceFormat($item->cartItemProductDiscount())); ?>

                                            </section>
                                            <?php endif; ?>
                                            <section class="text-nowrap fw-bold"><?php echo e(\App\Helpers\priceFormat($item->cartItemProductPrice())); ?> تومان</section>
                                        </section>
                                    </section>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                                </section>
                            </section>
                            <section class="col-3">
                                <section class="content-wrapper bg-white p-3 rounded-2 cart-total-price">
                                    <section class="d-flex justify-content-between align-items-center">
                                        <p class="text-muted">قیمت کالاها (<?php echo e($cartItems->count()); ?>)</p>
                                        <p id="total_product_price" class="text-muted"><?php echo e(\App\Helpers\priceFormat($totalProductPrice)); ?> تومان</p>
                                    </section>

                                    <section class="d-flex justify-content-between align-items-center">
                                        <p class="text-muted">تخفیف کالاها</p>
                                        <p id="total_discount" class="text-danger fw-bolder"><?php echo e(\App\Helpers\priceFormat($totalDiscount)); ?> تومان</p>
                                    </section>
                                    <section class="border-bottom mb-3"></section>
                                    <section class="d-flex justify-content-between align-items-center">
                                        <p class="text-muted">جمع سبد خرید</p>
                                        <p id="total_price" class="fw-bolder"><?php echo e(\App\Helpers\priceFormat($totalProductPrice - $totalDiscount)); ?> تومان</p>
                                    </section>

                                    <p class="my-3">
                                        <i class="fa fa-info-circle me-1"></i>کاربر گرامی  خرید شما هنوز نهایی نشده است. برای ثبت سفارش و تکمیل خرید باید ابتدا آدرس خود را انتخاب کنید و سپس نحوه ارسال را انتخاب کنید. نحوه ارسال انتخابی شما محاسبه و به این مبلغ اضافه شده خواهد شد. و در نهایت پرداخت این سفارش صورت میگیرد.
                                    </p>


                                    <section class="">

                                        <button type="submit" class="btn btn-danger d-block w-100">تکمیل فرآیند خرید</button>
                                    </section>

                                </section>
                            </section>
                        </section>
                        </form>
                    </section>
                </section>

            </section>
        </section>
        <!-- end cart -->




        <section class="mb-4">
            <section class="container-xxl" >
                <section class="row">
                    <section class="col">
                        <section class="content-wrapper bg-white p-3 rounded-2">
                            <!-- start vontent header -->
                            <section class="content-header">
                                <section class="d-flex justify-content-between align-items-center">
                                    <h2 class="content-header-title">
                                        <span>کالاهای مرتبط با سبد خرید شما</span>
                                    </h2>
                                    <section class="content-header-link">
                                        <!--<a href="#">مشاهده همه</a>-->
                                    </section>
                                </section>
                            </section>
                            <!-- start vontent header -->
                            <section class="lazyload-wrapper" >
                                <section class="lazyload light-owl-nav owl-carousel owl-theme">

                                    <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <section class="item">
                                        <section class="lazyload-item-wrapper">
                                            <section class="product">
                                                <section class="product-add-to-cart"><a href="#" data-bs-toggle="tooltip" data-bs-placement="left" title="افزودن به سبد خرید"><i class="fa fa-cart-plus"></i></a></section>
                                                <?php if(auth()->guard()->guest()): ?>
                                                    <section class="product-add-to-favorite">
                                                        <a  data-url="<?php echo e(route('customer.market.add-to-favorite',[$product->slug])); ?>" id="favorite<?php echo e($product->id); ?>" data-bs-toggle="tooltip" data-bs-placement="left" title="افزودن به علاقه مندی" onclick="addToFavorite(<?php echo e($product->id); ?>)">
                                                            <i id="fa" class="fa fa-heart text-dark"></i>
                                                        </a>
                                                    </section>
                                                <?php endif; ?>

                                                <?php if(auth()->guard()->check()): ?>
                                                    <?php if($product->users->contains(auth()->user()->id)): ?>
                                                        <section class="product-add-to-favorite">
                                                            <a  data-url="<?php echo e(route('customer.market.add-to-favorite',[$product->slug])); ?>" id="favorite<?php echo e($product->id); ?>" data-bs-toggle="tooltip" data-bs-placement="left" title="حذف از علاقه مندی" onclick="addToFavorite(<?php echo e($product->id); ?>)">
                                                                <i id="fa<?php echo e($product->id); ?>" class="fa fa-heart text-danger"></i>
                                                            </a>
                                                        </section>
                                                    <?php else: ?>
                                                        <section class="product-add-to-favorite">
                                                            <a  data-url="<?php echo e(route('customer.market.add-to-favorite',[$product->slug])); ?>" id="favorite<?php echo e($product->id); ?>" data-bs-toggle="tooltip" data-bs-placement="left" title="افزودن به علاقه مندی" onclick="addToFavorite(<?php echo e($product->id); ?>)">
                                                                <i id="fa<?php echo e($product->id); ?>" class="fa fa-heart text-dark"></i>
                                                            </a>
                                                        </section>
                                                    <?php endif; ?>

                                                <?php endif; ?>
                                                <a class="product-link" href="#">
                                                    <section class="product-image">
                                                        <img class="" src="<?php echo e(asset($product->image['indexArray']['medium'])); ?>" alt="<?php echo e($product->name); ?>">
                                                    </section>
                                                    <section class="product-name"><h3>  <?php echo e($product->name); ?></h3></section>
                                                    <section class="product-price-wrapper">
                                                        <section class="product-price"><?php echo e(\App\Helpers\priceFormat($product->price)); ?> تومان</section>
                                                    </section>
                                                    <section class="product-colors">
                                                        <?php $__currentLoopData = $product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <section class="product-colors-item" style="background-color: <?php echo e($color->color); ?>;"></section>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </section>
                                                </a>
                                            </section>
                                        </section>
                                    </section>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </section>
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>




    </main>
    <!-- end main one col -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function addToFavorite(id){
            let favorite = $('#favorite'+id)
            let icon = $('#fa'+id)
            let url = favorite.attr('data-url')
            $.ajax({
                url,
                type:'GET',
                success:(res)=>{
                    let {status} = res;
                    console.log(status)
                    if (status === 1){

                        icon.addClass('text-danger')
                        icon.removeClass('text-dark')
                        favorite.attr('data-bs-original-title','حذف از علاقه مندی ها')

                    }
                    else if (status === 2) {

                        icon.addClass('text-dark')
                        icon.removeClass('text-danger')
                        favorite.attr('data-bs-original-title','افزودن به علاقه مندی ها')


                    }

                    else if (status === 3) {

                        $('.toast').toast('show')

                    }
                },
                error:()=>{


                }

            })

        }
    </script>
    <script>

        $(document).ready(function (){

            bill()
            $('.cart-number').click(function (){
                bill()
            })
        })

        function bill(){
            console.log('bill')
            let totalProductPrice = 0;
            let totalDiscount = 0;
            let totalPrice = 0;
            $('.number').each(function (){
                let productPrice = parseFloat($(this).data('product-price'))
                let productDiscount = parseFloat($(this).data('product-discount'))
                let number = parseFloat($(this).val())
                totalProductPrice += productPrice * number
                totalDiscount += productDiscount * number


            })
            totalPrice = totalProductPrice - totalDiscount
            $('#total_product_price').html(toFarsiNumber(totalProductPrice))
            $('#total_discount').html(toFarsiNumber(totalDiscount))
            $('#total_price').html(toFarsiNumber(totalPrice))
        }

        function toFarsiNumber(number)
        {
            const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
            // add comma
            number = new Intl.NumberFormat().format(number);
            //convert to persian
            return number.toString().replace(/\d/g, x => farsiDigits[x]);
        }

        function deleteRecord(id){

            Swal.fire({
                title: 'آیا مطمین هستید؟',
                text: "می خواهید رکورد را حذف کنید؟",
                icon: 'warning',
                showCancelButton: true,
                cancelButtonText: 'انصراف',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'بله, حذف کن!'
            }).then((result) => {

                if (result.value) {
                    let element = $('#delete'+id)
                    let tr = $('#section'+id)
                    let url = element.attr('data-url')

                    $.ajax({
                        url,
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type:'POST',

                        success:(res)=>{

                            tr.remove()
                            bill()
                            Swal.fire({
                                icon: 'success',
                                title: 'موفق',
                                text: 'رکورد با موفقیت حذف شد',
                                confirmButtonText : 'باشه'
                            })

                        }
                    })
                }
            })


        }
    </script>


<?php $__env->stopSection(); ?>













<?php echo $__env->make('customer.layouts.master-one-col', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\shop\resources\views/customer/market/sales-process/cart.blade.php ENDPATH**/ ?>