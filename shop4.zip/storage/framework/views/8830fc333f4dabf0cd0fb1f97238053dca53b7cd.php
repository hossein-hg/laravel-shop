<?php $__env->startSection('head-tag'); ?>
    <title>تیکت</title>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>

    <section class="row">
        <section id="main-body-two-col" class="container-xxl body-container">
            <section class="row">
                <aside id="sidebar" class="sidebar col-md-3">


                    <section class="content-wrapper bg-white p-3 rounded-2 mb-3">
                        <?php echo $__env->make('customer.layouts.partials.profile-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </section>

                </aside>


                <main id="main-body" class="main-body col-md-9">
                    <section class="content-wrapper bg-white p-3 rounded-2 mb-2">

                        <section class="card mb-3">
                            <section class="card-header bg-custom-yellow d-flex justify-content-between">
                                <div><?php echo e($ticket->user->fullName); ?></div>
                                <div><?php echo e(\App\Helpers\jalaliDate($ticket->created_at)); ?></div>
                            </section>
                            <section class="card-body">
                                <h5 class="card-title">عنوان تیکت : <?php echo e($ticket->subject); ?></h5>
                                <p class="card-text"><?php echo e($ticket->description); ?></p>
                            </section>
                            <?php if($ticket->file): ?>
                            <section class="card-footer">

                                <a download href="<?php echo e(asset($ticket->file->file_path)); ?>" class="btn btn-info"> فایل دانلود</a>
                            </section>
                            <?php endif; ?>
                        </section>

                        <hr>
                        <?php $__currentLoopData = $ticket->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <section class="card mb-3 m-4">
                            <section class="card-header bg-info d-flex justify-content-between">
                                <?php if($child->reference): ?>
                                    <div><?php echo e($child->reference->user->fullName); ?></div>
                                <?php else: ?>
                                    <div><?php echo e($child->user->fullName); ?></div>
                                <?php endif; ?>
                                <div><?php echo e(\App\Helpers\jalaliDate($child->created_at)); ?></div>
                            </section>
                            <section class="card-body">

                                <p class="card-text"><?php echo e($child->description); ?></p>
                            </section>

                        </section>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($ticket->status == 0): ?>
                        <section >
                            <form action="<?php echo e(route('customer.profile.my-tickets.answer',[$ticket->id])); ?>" method="post">
                                <section class="row">

                                    <section class="col-12 ">

                                        <?php echo csrf_field(); ?>

                                        <div class="form-group">
                                            <label for="">پاسخ تیکت </label>
                                            <textarea  name="description"  rows="4" class="form-control form-control-sm"><?php echo e(old('description')); ?></textarea>
                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div  class="form-group mt-2">
                                            <button type="submit" class="btn btn-success">ثبت</button>
                                        </div>

                                    </section>


                                </section>
                            </form>

                        </section>
                        <?php else: ?>
                            <section class="bg-danger text-white p-3">این تیکت بسته شده است</section>
                        <?php endif; ?>

                    </section>
                </main>




            </section>
        </section>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.master-one-col', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\shop\resources\views/customer/profile/tickets/my-tickets-show.blade.php ENDPATH**/ ?>